package com.capgemini.tcc.dao;

public class QueryMapper {
	public static final String INSERTQUERY="insert into patient values(?,?,?,?,?,?)";
	public static final String SEARCHQUERY="select * from patient where patient_id=?";		
	
	
	
	
}
