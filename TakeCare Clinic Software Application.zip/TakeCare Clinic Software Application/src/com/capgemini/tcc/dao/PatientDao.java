package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.tcc.Exception.PatientException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.logger.MyLogger;
import com.capgemini.tcc.util.DBUtil;


public class PatientDao implements IPatientDao {
	Connection connection;
  Logger logger;
	
	public PatientDao()
	{
		
		logger = MyLogger.getLogger();
	
	}
	public int generatepurchaseId() {
		  logger.info("In generatePatientId method ");
		int patientId = 0;
		String SQL = "select patient_id_seq.nextval from dual";
		connection = DBUtil.getConnection();
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(SQL);
			resultSet.next();
			patientId = resultSet.getInt(1);
			logger.info("Got patientId "+patientId);
		} catch (SQLException e) {
			
			logger.error(e.getMessage());
			System.err.println(e.getMessage());

		}
		logger.info("Completed Method patientId");
		return patientId;
	}
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		// TODO Auto-generated method stub
	
			logger.info("In Add detail");
			logger.info("Input is"+patient);
			connection = DBUtil.getConnection();
			int patientId=generatepurchaseId();
			try {
				PreparedStatement preparedStatement = connection
						.prepareStatement(QueryMapper.INSERTQUERY);
				preparedStatement.setInt(1,patientId);
				preparedStatement.setString(2,patient.getPatient_Name());
				preparedStatement.setInt(3, patient.getAge());
				preparedStatement.setString(4, patient.getPhone());
				preparedStatement.setString(5, patient.getDescription());
				java.sql.Date date=Date.valueOf(patient.getConsultant_date());
				preparedStatement.setDate(6, date);
				preparedStatement.executeUpdate();
				logger.info("inserted successfully and id is = "+patientId);
				connection.commit();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				e.printStackTrace();

			}
			return patientId;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException {
		// TODO Auto-generated method stub
		PatientBean pb=new PatientBean();
		try{
			 connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.SEARCHQUERY);
		
		preparedStatement.setInt(1,patientId);

		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
		        pb.setPatient_Id(resultSet.getInt(1));
				pb.setPatient_Name(resultSet.getString(2));
				pb.setAge(resultSet.getInt(3));
				pb.setPhone(resultSet.getString(4));
				pb.setDescription(resultSet.getString(5));
				pb.setConsultant_date(resultSet.getDate(6).toLocalDate());
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return pb;
		
	}
	}

	


