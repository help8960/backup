package com.capgemini.tcc.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import oracle.net.aso.d;

import com.capgemini.tcc.Exception.PatientException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;


public class Client {

public static void main(String[] args) {
IPatientService service= new PatientService();	
Scanner sc=new Scanner(System.in);	
System.out.println("****************************************************");
System.out.println("*                                                  *");
System.out.println("*       TakeCare Clinic Software Application       *");
System.out.println("*                                                  *");
System.out.println("****************************************************");

System.out.println("Choose an Option");
System.out.println("Enter 1 for Adding Patient Information");
System.out.println("Enter 2 for Search Patient By Id");
System.out.println("Enter 3 for exit");
int choice=sc.nextInt();
switch(choice)
{
case 1:
	System.out.println("Name of Patient :");
	String name=sc.next();
	System.out.println("Enter Age :");
	int age=sc.nextInt();
	System.out.println("Phone number :");
	String phone=sc.next();
	System.out.println("Enter Description :");
	String desc=sc.next();
	System.out.println("Enter Consultant Date in (dd/mm/yyyy) format :");
	String date=sc.next();
	DateTimeFormatter format = 
			DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate consultationdate = LocalDate.parse(date, format);
	
	PatientBean patient=new PatientBean(name,age,phone,desc,consultationdate);
	try {
		System.out.println("Details entered with Id"+service.addPatientDetails(patient));
	} catch (PatientException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       break;
       
case 2:
	System.out.println("Enter Id to get Detail");
	int id=sc.nextInt();
	try {
		PatientBean pb=service.getPatientDetails(id);
		System.out.println("Name of Patient   : "+pb.getPatient_Name());
		System.out.println("Age               : "+pb.getAge());
		System.out.println("Phone Number      : "+pb.getPhone());
		System.out.println("Consultation Date : "+pb.getConsultant_date());
		
	} catch (PatientException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}


}

}
