package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.mra.beans.Account;
import com.cg.mra.utility.DBUtil;

public class AccountDaoImpl implements AccountDao{
       Connection connection;
	@Override
	public Account getAccountDetails(String accountId) {
		connection = DBUtil.getConnection();
		Statement statement;
		Account account= new Account();
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(Query.SEARCHQUERY);
			preparedStatement.setString(1, accountId);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				account.setAccountBalance(resultSet.getDouble(1));
		}
		}
			catch (SQLException e) {
			  e.printStackTrace();
		}
		
    return account;
	}
	
	
	
    @Override
	public int rechargeAccount(String accountId, double rechargeAmount) {
    	connection = DBUtil.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(Query.UPDATEQUERY);
			
			preparedStatement.setDouble(1,rechargeAmount);
			preparedStatement.setString(2, accountId);
			preparedStatement.executeUpdate();
			}
		catch(SQLException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		return 0;
	
}
}