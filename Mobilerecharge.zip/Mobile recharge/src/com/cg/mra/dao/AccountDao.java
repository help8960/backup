package com.cg.mra.dao;

import com.cg.mra.beans.Account;

public interface AccountDao {
	
public Account getAccountDetails(String accountId);
public int rechargeAccount(String accountId,double rechargeAmount);

}
