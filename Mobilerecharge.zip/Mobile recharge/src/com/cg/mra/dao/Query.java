package com.cg.mra.dao;

public class Query {
public static final String SEARCHQUERY="select balance from Account where account_Id=?";
public static final String UPDATEQUERY="update account set balance=(balance+?) where account_Id=?";
}
