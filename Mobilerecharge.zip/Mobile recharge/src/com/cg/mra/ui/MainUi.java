package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUi {
 
	public static void main(String[] args) {
		AccountService service=new AccountServiceImpl();
		System.out.println("###### MOBILE RECHARGE SYSTEM ######");
		System.out.println("Enter 1 for balance enquiry");
		System.out.println("Enter 2 for recharge");
		System.out.println("Press 3 for Exit");
		System.out.println("Enter your choice");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
		System.out.println("Enter your accountid");
		String id=sc.next();
	Account p=service.getAccountDetails(id);

		System.out.println("Your recharge amount is "+p.getAccountBalance());
		MainUi.main(null);
		break;
		case 2:
			System.out.println("Enter recharge amount");
			double recharge=sc.nextDouble();
			System.out.println("Enter AccountId");
			String id1=sc.next();
			service.rechargeAccount(id1, recharge);
			System.out.println("Account updated");
			MainUi.main(null);
			break;
			
		case 3:
		System.out.println("System exited Successfully");
		System.exit(0);
		
		
		}
		
	
	
	
	}

}
