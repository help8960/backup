package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountService {
	public Account getAccountDetails(String accountId);
	public int rechargeAccount(String accountId,double rechargeAmount);


}
