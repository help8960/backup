package com.cg.frs.dto;

public class FlatRegistrationDTO {
	
//private int flat_reg_id;
private int owner_id;
private int flat_type;
private int flat_area;
private int rent_amount;
private int deposit_amount;


public int getOwner_id() {
	return owner_id;
}
public void setOwner_id(int owner_id) {
	this.owner_id = owner_id;
}
public int getFlat_type() {
	return flat_type;
}
public void setFlat_type(int flat_type) {
	this.flat_type = flat_type;
}
public int getFlat_area() {
	return flat_area;
}
public void setFlat_area(int flat_area) {
	this.flat_area = flat_area;
}
public int getRent_amount() {
	return rent_amount;
}
public void setRent_amount(int rent_amount) {
	this.rent_amount = rent_amount;
}
public int getDeposit_amount() {
	return deposit_amount;
}
public void setDeposit_amount(int deposit_amount) {
	this.deposit_amount = deposit_amount;
}
public FlatRegistrationDTO(int owner_id, int flat_type,
		int flat_area, int rent_amount, int deposit_amount) {
	super();

	this.owner_id = owner_id;
	this.flat_type = flat_type;
	this.flat_area = flat_area;
	this.rent_amount = rent_amount;
	this.deposit_amount = deposit_amount;
}













}
