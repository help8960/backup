package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.dto.Flatowner;
import com.cg.frs.utility.DBUtil;

public class IFlatRegistrationDAOImpl implements IFlatRegistrationDAO {

	Connection connection;
	
	Logger logger=Logger.getRootLogger();
	public IFlatRegistrationDAOImpl() {
		PropertyConfigurator.configure("ResourceS/log4j.properties");
		
	}

	@Override
	public int generateflatId() {
		// TODO Auto-generated method stub
		int flat_reg_id = 0;
		String SQL = "select flat_seq.nextval from dual";
		connection = DBUtil.getConnection();
		try {
			Statement statement = (Statement) connection.createStatement();
			ResultSet resultSet = statement.executeQuery(SQL);
			resultSet.next();
			flat_reg_id = resultSet.getInt(1);
			//System.out.println(flatId);
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return flat_reg_id;
	}

	@Override
	public int RegisterFlat(FlatRegistrationDTO flatregisterdto) {
		// TODO Auto-generated method stub
		int flat_reg_id=generateflatId();
		connection = DBUtil.getConnection();

		try {
			
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTQUERY);
			System.out.println(flatregisterdto.getOwner_id());
			preparedStatement.setInt(1,flat_reg_id);
			preparedStatement.setInt(2,flatregisterdto.getOwner_id());
			preparedStatement.setInt(3,flatregisterdto.getFlat_type());
			preparedStatement.setInt(4,flatregisterdto.getFlat_area());
			preparedStatement.setInt(5,flatregisterdto.getRent_amount());
			preparedStatement.setInt(6,flatregisterdto.getDeposit_amount());
			preparedStatement.executeUpdate();
		}
		catch(Exception E){
			logger.error(E.getMessage());
			//E.printStackTrace();
		}
		return flat_reg_id;
	}

	@Override
	public List<Integer> getOwnerId() {
		List<Integer> getallownerid = new ArrayList<Integer>();
		connection = DBUtil.getConnection();
		Statement statement;
		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(QueryMapper.SELECTQUERY);
			while (resultSet.next()) {
				
				Flatowner flatowner=new Flatowner();
				flatowner.setOwner_id(resultSet.getInt(1));
				//flatowner.setOwnername(resultSet.getString(2));
				//flatowner.setMobile(resultSet.getString(3));
				getallownerid.add(flatowner.getOwner_id());
				
			}
		
	}
		catch(Exception e){
			logger.error(e.getMessage());
			//e.printStackTrace();
		}


		return getallownerid;
	}
	

}
