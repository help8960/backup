package com.cg.frs.utility;


import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import org.apache.log4j.Logger;

public class DBUtil {
	private static Connection connection;
	static Logger logger=Logger.getLogger(DBUtil.class);
      public static Connection getConnection()
      {
    logger.info("Start of get connection method");
      if(connection==null)
      {
      
    	  try {
    			FileReader reader=new FileReader("Resources\\jdbc.properties");
    			Properties properties=new Properties();
    			properties.load(reader);
    			Class.forName(properties.getProperty("driver"));
    			
    			connection=DriverManager.getConnection(properties.getProperty("url"),
    					properties.getProperty("userName"),
    					properties.getProperty("password"));
    			} 
    	  catch (IOException e) {
  		  //TODO Auto-generated catch block
  			e.printStackTrace();
  		}
    	  catch (ClassNotFoundException e) {
  			// TODO Auto-generated catch block
    		 logger.error("problem occured while loading the driver class"+e.getMessage());
  			e.printStackTrace();
  		}
    catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	  
      
    			
      }
      logger.info("End of get connection method");
	return connection;		
      		
    		
      }
      
      }

