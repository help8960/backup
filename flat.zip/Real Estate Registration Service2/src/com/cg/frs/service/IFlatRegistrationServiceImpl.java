package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dao.IFlatRegistrationDAOImpl;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.dto.Flatowner;
import com.cg.frs.exception.RegistrationException;

public class IFlatRegistrationServiceImpl implements IFlatRegistrationService{
IFlatRegistrationDAO dao= new IFlatRegistrationDAOImpl();

@Override
public List<Integer> getOwnerId() {
	return dao.getOwnerId();
}

@Override
public int RegisterFlat(FlatRegistrationDTO flatregisterdto) {
	
	return dao.RegisterFlat(flatregisterdto)
			;
	
}

@Override
public int generateflatId() {
	// TODO Auto-generated method stub
	return dao.generateflatId();
}

@Override
public boolean validateRegisterDetails(FlatRegistrationDTO flatregisterdto)
		throws RegistrationException {
	boolean d=false;
	List<Integer> flat=dao.getOwnerId();
	for(Integer i:flat)
	{
	if((flatregisterdto.getOwner_id()==i)){
		d=true;
		break;
	}
	}
if(d==false)
{
	
	throw new RegistrationException("Invalid owner id");
	
}
	
	
	
	return true;
	

}
}