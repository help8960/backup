package com.cg.frs.service;

import java.util.List;


import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.dto.Flatowner;
import com.cg.frs.exception.RegistrationException;

public interface IFlatRegistrationService {

	public List<Integer> getOwnerId();
	public int generateflatId();
	public int RegisterFlat(FlatRegistrationDTO flatregisterdto);
	public boolean validateRegisterDetails(FlatRegistrationDTO flatregisterdto) throws RegistrationException;

}
