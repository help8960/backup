package com.capgemini.banks.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.banks.dao.DemandDraftDao;
import com.capgemini.banks.dao.IDemandDraftDao;

public class DemandDraftService implements IDemandDraftService{
 IDemandDraftDao dao=new DemandDraftDao();
	@Override
	public int addDemandDraftDetails(DemandDraft demanddraft) {
		// TODO Auto-generated method stub
		return dao.addDemandDraftDetails(demanddraft);
	}

	@Override
	public DemandDraft getDemandDraftDeatails(int transactionId) {
		// TODO Auto-generated method stub
		return dao.getDemandDraftDeatails(transactionId);
	}

}
