package com.capgemini.banks.service;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demanddraft);
	DemandDraft getDemandDraftDeatails(int transactionId);


}
