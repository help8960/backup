package com.capgemini.banks.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.bank.bean.DemandDraft;

import com.capgemini.banks.utility.DBUtil;
import com.capgemini.banks.dao.QueryMapper;

public class DemandDraftDao implements IDemandDraftDao {
	 Connection connection;
	public int generatetransactionId() {
		// TODO Auto-generated method stub
		int transactionId = 0;
		String SQL = "select transaction_id_seq.nextval from dual";
		connection = DBUtil.getConnection();
		try {
			Statement statement = (Statement) connection.createStatement();
			ResultSet resultSet = statement.executeQuery(SQL);
			resultSet.next();
			transactionId = resultSet.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return transactionId;
	}
	
	
	@Override
	public int addDemandDraftDetails(DemandDraft demanddraft) {
		// TODO Auto-generated method stub
		int transactionId = generatetransactionId();
	    connection = DBUtil.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTQUERY);
			preparedStatement.setInt(1, transactionId);
			preparedStatement.setString(2, demanddraft.getCustomer_name());
			preparedStatement.setString(3, demanddraft.getIn_favor_of());
			preparedStatement.setString(4, demanddraft.getPhone_number());
			preparedStatement.setDouble(5, demanddraft.getDd_amount());
			preparedStatement.setInt(6,demanddraft.getDd_commission());
			preparedStatement.setString(7,demanddraft.getDd_description());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return transactionId;
	}

	@Override
	public DemandDraft getDemandDraftDeatails(int transactionId) {
		DemandDraft dd=new DemandDraft();
		try{
			 connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.PRINT);
		
		preparedStatement.setInt(1, transactionId);

		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			dd.setDd_amount(resultSet.getDouble(1));
			dd.setDd_commission(resultSet.getInt(2));
			dd.setDd_description(resultSet.getString(3));
	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return dd;
		
	}

}





































