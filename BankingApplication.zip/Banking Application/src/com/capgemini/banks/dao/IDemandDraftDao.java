package com.capgemini.banks.dao;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftDao {
	
int addDemandDraftDetails(DemandDraft demanddraft);
DemandDraft getDemandDraftDeatails(int transactionId);

}
 