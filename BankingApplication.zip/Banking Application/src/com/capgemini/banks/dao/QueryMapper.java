package com.capgemini.banks.dao;

public class QueryMapper {
public static final String INSERTQUERY="insert into demand_draft values(?,?,?,?,sysdate,?,?,?)";
public static final String PRINT="select dd_amount,dd_commission,dd_description from demand_draft where transaction_id=?";
}
