
package com.capgemini.banks.bean.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.banks.service.DemandDraftService;
import com.capgemini.banks.service.IDemandDraftService;

public class Client {
	
public static void main(String[] args) {
IDemandDraftService service=new DemandDraftService();
Scanner sc=new Scanner(System.in);
System.out.println("#######Banking Application#########");
System.out.println("Enter 1 for Enter Demand Draft Deatails");
System.out.println("Enter 2 Print Demand Draft Details");
System.out.println("Enter 3 fror exit");
int choice=sc.nextInt();
switch(choice)
{
case 1:
int ddc=0;
System.out.println("Enter Your Name");
String name=sc.next();
System.out.println("Enter Your Phone number");
String phone=sc.next();
System.out.println("In favor of");
String favor=sc.next();
System.out.println("Enter dd amount in rs");
Double amount=sc.nextDouble();
System.out.println("Enter Remark");
String descrip=sc.next();
//LocalDate currentDate = LocalDate.now();
if(amount>=5000)
{
	ddc=10;
}
else if(5001<=amount && amount<10000)
{
	ddc=41;
}
else if(10001<=amount && amount<100000)
{
	ddc=51;
}
else if(100001<=amount && amount<500000)
{
	ddc=306;
}
DemandDraft dd=new DemandDraft(name,phone,favor,amount,ddc,descrip);
System.out.println("Demand draft registered with id "+service.addDemandDraftDetails(dd));
Client.main(null);
break;
case 2:
	System.out.println("Enter Transactionid");
	int ti=sc.nextInt();
	DemandDraft d=service.getDemandDraftDeatails(ti);
	System.out.println("NAME OF BANK  : SBI");
	System.out.println("DDAMOUNT      : "+d.getDd_amount());
	System.out.println("DD Commission : "+d.getDd_commission());
	System.out.println("Total Amount  : "+d.getDd_amount()+d.getDd_commission());
	System.out.println("Remarks       : "+d.getDd_description());
	break;
case 3:
	System.exit(0);
}
}

}
