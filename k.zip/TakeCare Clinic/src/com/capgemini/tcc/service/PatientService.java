package com.capgemini.tcc.service;

import com.capgemini.tcc.Exception.PatientException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDao;
import com.capgemini.tcc.dao.PatientDao;

public class PatientService implements IPatientService {
   IPatientDao ip=new PatientDao();
   
   @Override
	public PatientBean getPatientDetails(int patientId) throws PatientException {
		
		return ip.getPatientDetails(patientId);
	}

	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {

		return ip.addPatientDetails(patient);
	}

	
}
