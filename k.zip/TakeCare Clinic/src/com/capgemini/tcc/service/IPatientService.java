package com.capgemini.tcc.service;

import com.capgemini.tcc.Exception.PatientException;
import com.capgemini.tcc.bean.PatientBean;

public interface IPatientService {

	public int addPatientDetails(PatientBean patient) throws PatientException;
	public PatientBean getPatientDetails(int patientId) throws PatientException;
    
}
