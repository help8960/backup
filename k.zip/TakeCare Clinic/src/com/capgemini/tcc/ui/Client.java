package com.capgemini.tcc.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import oracle.net.aso.d;

import com.capgemini.tcc.Exception.PatientException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		IPatientService service = new PatientService();
		Scanner scanner = new Scanner(System.in);
		System.out.println("************************************");
		System.out.println("	Choose an Option");
		System.out.println("	1.Adding Patient Information");
		System.out.println("	2.Search Patient By Id");
		System.out.println("	3.exit");
		System.out.println("************************************");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Name of Patient :");
			String name = scanner.next();
			System.out.println("Age:");
			int age = scanner.nextInt();
			System.out.println("Phone number :");
			String phone = scanner.next();
			System.out.println("Description :");
			String desc = scanner.next();
			System.out.println("Consultant Date in (dd/mm/yyyy) format :");
			String date = scanner.next();
			DateTimeFormatter format = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			LocalDate consultationdate = LocalDate.parse(date, format);

			PatientBean patient = new PatientBean(name, age, phone, desc,
					consultationdate);
			try {
				System.out.println("Details entered with Id"
						+ service.addPatientDetails(patient));
			} catch (PatientException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

		case 2:
			System.out.println("Enter Id to get Detail");
			int id = scanner.nextInt();
			try {
				PatientBean pb = service.getPatientDetails(id);
				System.out.println("Name of Patient   : "
						+ pb.getPatient_Name());
				System.out.println("Age               : " + pb.getAge());
				System.out.println("Phone Number      : " + pb.getPhone());
				System.out.println("Consultation Date : "
						+ pb.getConsultant_date());

			} catch (PatientException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 3:
			// Exit
			System.exit(0);
			break;

		default:
			System.out.println("Enter correct choice");
			break;
		}
	}

}
