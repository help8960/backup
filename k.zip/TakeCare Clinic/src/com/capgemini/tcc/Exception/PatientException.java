package com.capgemini.tcc.Exception;

public class PatientException extends Exception {

	String message;
	public PatientException(String message)
	{
		this.message=message;	
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
}
