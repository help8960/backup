package com.capgemini.tcc.bean;

import java.time.LocalDate;

public class PatientBean {
	private int patient_Id;
	private String patient_Name;
	private int age;
	private String phone;
	private String description;
	private LocalDate consultant_date;

	public PatientBean() {

	}

	public int getPatient_Id() {
		return patient_Id;
	}

	public void setPatient_Id(int patient_Id) {
		this.patient_Id = patient_Id;
	}

	public String getPatient_Name() {
		return patient_Name;
	}

	public void setPatient_Name(String patient_Name) {
		this.patient_Name = patient_Name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhone() {
		return phone;
	}

	public PatientBean(String patient_Name, int age, String phone,
			String description, LocalDate consultant_date) {
		super();
		this.patient_Name = patient_Name;
		this.age = age;
		this.phone = phone;
		this.description = description;
		this.consultant_date = consultant_date;
	}

	@Override
	public String toString() {
		return "PatientBean [patient_Id=" + patient_Id + ", patient_Name="
				+ patient_Name + ", age=" + age + ", phone=" + phone
				+ ", description=" + description + ", consultant_date="
				+ consultant_date + "]";
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getConsultant_date() {
		return consultant_date;
	}

	public void setConsultant_date(LocalDate consultant_date) {
		this.consultant_date = consultant_date;
	}

}
