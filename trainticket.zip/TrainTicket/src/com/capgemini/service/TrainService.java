package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;

public interface TrainService {
	public ArrayList<TrainBean> retrieveTrainDetails();
	public int generateBookingId();
	public int bookTicket(BookingBean bookingbean)throws BookingException;
	public boolean validateBookingDetails(BookingBean bookingbean) throws BookingException;
}
