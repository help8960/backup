package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;

public interface TrainDao {
	
	public ArrayList<TrainBean> retrieveTrainDetails();
	public int generateBookingId();
	public int bookTicket(BookingBean bookingbean)throws BookingException;
	

}
