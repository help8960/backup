package com.capgemini.bean;

import java.util.Date;

public class TrainBean {
	private int trainId;
	private String trainType;
	private Date dateOfJourney; 
	private String fromStop,toStop;
	private int availableSeats;
	private int fare;
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public String getTrainType() {
		return trainType;
	}
	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}
	public Date getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(Date dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	@Override
	public String toString() {
		return "TrainBean [trainId=" + trainId + ", trainType=" + trainType
				+ ", dateOfJourney=" + dateOfJourney + ", fromStop=" + fromStop
				+ ", toStop=" + toStop + ", availableSeats=" + availableSeats
				+ ", fare=" + fare + "]";
	}
	

}
