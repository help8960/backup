package com.capgemini.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.service.TrainServiceImpl;



public class TrainDaoTest {

	TrainServiceImpl service;
	TrainDaoImpl dao;
	
	@Before
	public void init()
	{
		dao = new TrainDaoImpl();
		service = new TrainServiceImpl();
		service.setDao(dao);
	}
	@Test
	public void testretrieveTrainDetails() throws BookingException
	{
		ArrayList<TrainBean>list = service.retrieveTrainDetails();
		assertNotNull(list);
	}
	@Test
	public void testbookTicket() throws BookingException
	{
		BookingBean obj=new BookingBean();
		obj.setBookingId(100);
		obj.setCustId("76");;
		obj.setNoOfseat(5);
		obj.setTrainId(2);
		int id = service.bookTicket(obj);
		assertNotSame(id,0);
	}
	
	

}

