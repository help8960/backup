package com.capgemini.contactbook.ui;

import java.util.Scanner;

import com.capgemini.contactbook.Exception.ContactBookException;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.IContactBookService;

public class Client {

public static void main(String[] args) {
	IContactBookService service=new ContactBookService();
Scanner sc=new Scanner(System.in);	
System.out.println("***************************************");
System.out.println("*                                     *");
System.out.println("*     Global Recruitment System       *");
System.out.println("*                                     *");
System.out.println("***************************************");

System.out.println("Choose an Operation");
System.out.println("Enter 1 for Entering Enquiry Detail");
System.out.println("Enter 2 for Enquiry Detail By Id");
System.out.println("Enter 0 for exit");
int choice=sc.nextInt();
switch(choice)
{
case 1:
System.out.println("First Name :");
String fname=sc.next();
System.out.println("Last Name :");
String lname=sc.next();
System.out.println("Phone number :");
String cn=sc.next();
System.out.println("Domain :");
String domain=sc.next();
System.out.println("Preferred Location:");
String loc=sc.next();
EnquiryBean obj=new EnquiryBean(fname,lname,cn,domain,loc);
	try {
		if (service.isvalidEnquiry(obj))
		{
			System.out.println("Your Enquiry registered with id "+service.addEnquiry(obj));
		}
		
	} catch (ContactBookException e) {
		// TODO Auto-generated catch block
		System.err.println(e.getMessage());}
	
	break; 
	
case 2:
	System.out.println("Enter your Id");
	String id=sc.next();
	
	try {
		int i;
		EnquiryBean ee=service.getEnquiryDetails(i=Integer.parseInt(id));
		 int v=ee.getEnqryId();
		 
       if (service.isValidId(v))
    	   
       {
		System.out.println("Details for id = "+id+ " are.");
		System.out.println("First Name      : "+ee.getfName());
		
		System.out.println("Last Name       : "+ee.getlName());
		
		System.out.println("Phone number    : "+ee.getContactNo());
		
		System.out.println("Domain          : "+ee.getpDomain());
		
		System.out.println("Preferred Location: "+ee.getpLocation());
       }
	} catch (ContactBookException e) {
		// TODO Auto-generated catch block
		System.err.println(e.getMessage());
	}

	break;
}

}
}
