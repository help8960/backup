package com.capgemini.contactbook.dao;

public class QueryMapper {
	public static final String SELECTQUERY="select * from enquiry where enqryId=?";
	public static final String INSERTQUERY="insert into enquiry values(?,?,?,?,?,?)";
	

}
