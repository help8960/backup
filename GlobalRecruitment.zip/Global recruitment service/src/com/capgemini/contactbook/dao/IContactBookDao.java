package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.Exception.ContactBookException;
import com.capgemini.contactbook.bean.EnquiryBean;

public interface IContactBookDao {
public int addEnquiry(EnquiryBean enqry)throws ContactBookException;
public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException;
}
