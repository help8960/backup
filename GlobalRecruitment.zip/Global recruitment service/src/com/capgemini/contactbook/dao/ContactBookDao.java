package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.Exception.ContactBookException;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.utility.DBUtil;
import com.cg.logger.MyLogger;



public class ContactBookDao implements IContactBookDao{
	

Connection connection;
Logger logger;
public ContactBookDao() {
	connection = DBUtil.getConnection();
	logger = MyLogger.getLogger();
}
	public int generateflatId() {
		// TODO Auto-generated method stub
		logger.info("In getEmployeeId");
		int enquiryId = 0;
		String SQL = "select enquiries.nextval from dual";
		connection = DBUtil.getConnection();
		try {
			Statement statement = (Statement) connection.createStatement();
			ResultSet resultSet = statement.executeQuery(SQL);
			resultSet.next();
			enquiryId = resultSet.getInt(1);
			logger.info("Got Enquiry with id"+enquiryId);
			//System.out.println(flatId);
		} catch (SQLException e) {
			logger.error("error "+e.getMessage());
			System.out.println(e.getMessage());

		}logger.info("Completed getEnquiryId");
		return enquiryId;
	}
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		logger.info("In Add Enquiry");
		logger.info("input is"+enqry);
		int enquiryId=generateflatId();
		connection = DBUtil.getConnection();

		try {
			
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTQUERY);
			
			preparedStatement.setInt(1,enquiryId);
			preparedStatement.setString(2,enqry.getfName());
			preparedStatement.setString(3,enqry.getlName());
			preparedStatement.setString(4,enqry.getContactNo());
			preparedStatement.setString(5,enqry.getpDomain());
			preparedStatement.setString(6,enqry.getpLocation());
			preparedStatement.executeUpdate();
			logger.info("inserted successfully and id is = "+enquiryId);
		}
		catch(Exception e){
			logger.error("error in insert = "+e.getMessage());
			System.err.println(e.getMessage());
		}
		return enquiryId;
	}
	

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		EnquiryBean eb=new EnquiryBean();
		try{
			 connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.SELECTQUERY);
		
		preparedStatement.setInt(1, EnquiryID);

		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			eb.setEnqryId(resultSet.getInt(1));
			eb.setfName(resultSet.getString(2));
			eb.setlName(resultSet.getString(3));
			eb.setContactNo(resultSet.getString(4));
			eb.setpDomain(resultSet.getString(5));
			eb.setpLocation(resultSet.getString(6));
	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return eb;
		
	}
	}
	


