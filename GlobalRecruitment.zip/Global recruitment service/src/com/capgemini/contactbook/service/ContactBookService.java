package com.capgemini.contactbook.service;

import java.util.regex.Pattern;

import com.capgemini.contactbook.Exception.ContactBookException;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.IContactBookDao;

public class ContactBookService implements IContactBookService{
  IContactBookDao dao=new ContactBookDao();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		
		return dao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		// TODO Auto-generated method stub
		return dao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public boolean isvalidEnquiry(EnquiryBean enqry)throws ContactBookException {
			
			Boolean flag=true;
			String regx="[A-Z][a-z]{4,20}";
			String regx1="[6-9][0-9]{9}";  
			String regx2="[A-Za-z]{3,20}";	
			String regx3="[A-Za-z]{2,20}";
			String regx4="[A-Za-z]{2,20}";
			
		
				if(!Pattern.matches((regx),enqry.getfName()))
				{
					flag=false;
					throw new ContactBookException("Firstname should start with Capital letter & size should be 4 to 20");
				}
			
				if(!Pattern.matches(regx1,enqry.getContactNo()))
				{
					flag=false;
					throw new ContactBookException("Contact number should be 10 digit valid mobile number ");
				}
				
				
				if(!Pattern.matches(regx2,enqry.getlName()))
				{
					flag=false;
					throw new ContactBookException("Last name is required and it should not be empty ");
				}
				
				if(!Pattern.matches(regx3,enqry.getpLocation()))
				{
					flag=false;
					throw new ContactBookException("Preferred Location is required and it should not be empty ");
				}

			
				if(!Pattern.matches(regx4,enqry.getpDomain()))
				{
					flag=false;
					throw new ContactBookException("Preferred Domain is required and it should not be empty");
				}

			return flag;
		
	
	}

	@Override
	public boolean isValidId(int v) throws ContactBookException {
		
		Boolean flag=true;
		String regx="[1-9]{4}";
		
	
		if(!Pattern.matches(regx,v+""))
		{
			
			flag=false;
			throw new ContactBookException("Id pattern is wrong");
		}	
		
	else if(v==0)
      {
     
      throw new ContactBookException("This Id does not exist in database");
      
      }
	  else{
		  return true;
	  }
	}
	

	
	
	/*public boolean isvalidEnquiry(EnquiryBean enqry)
			throws ContactBookException {
		
		return false;
	}

	public boolean validateContactNo (String ContactNo)
	{
		String pattern = "[0-9]{10}";
		if(Pattern.matches(pattern,ContactNo))
		{
			return true;
		}
		else
			return false;
		
		
	}
	public boolean validateFirstName (String fName)
	{
		String pattern = "[A-Z,a-z]{4,}";
		if(Pattern.matches(pattern,fName))
		{
			return true;
		}
		else
			return false;
		
	}
	public boolean validateLastName(String lName)
	{
		String pattern = "[A-Z,a-z]{4,}";
		if(Pattern.matches(pattern,lName))
		{
			return true;
		}
		else
			return false;
		
	}
	public boolean validatePLocation(String pLocation )
	{
		String pattern = "[A-Z,a-z]{4,}";
		if(Pattern.matches(pattern,pLocation))
		{
			return true;
		}
		else
			return false;
		
	}
	*/
	}
	
