package com.capgemini.contactbook.service;


import com.capgemini.contactbook.Exception.ContactBookException;
import com.capgemini.contactbook.bean.EnquiryBean;

public interface IContactBookService {
	public int addEnquiry(EnquiryBean enqry)throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException;
	public boolean isvalidEnquiry(EnquiryBean enqry) throws ContactBookException;
	public boolean isValidId(int v) throws ContactBookException;
	//public boolean validateContactDetails(EnquiryBean enqry) throws ContactBookException;
}
