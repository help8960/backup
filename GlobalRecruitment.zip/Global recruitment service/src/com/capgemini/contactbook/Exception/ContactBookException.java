package com.capgemini.contactbook.Exception;

public class ContactBookException extends Exception {
String message;
	
	 public ContactBookException(String message) {
		// TODO Auto-generated constructor stub
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return this.message;
	}

}

