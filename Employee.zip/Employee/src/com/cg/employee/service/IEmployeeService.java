package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface IEmployeeService {
	public int addEmployee(Employee obj)throws EmployeeException;
	public ArrayList<Employee> getAllEmployee()throws EmployeeException;
	public Employee getEmployeeId(int empId)throws EmployeeException;
	public int RemoveById(int empId)throws EmployeeException;
	public int updateEmployee(int empId,int empsal)throws EmployeeException;
	public boolean validateName(String name);
	public boolean validateSalary(int salary);
	public boolean validateId(int empId);
	//public boolean validateDate(String date);
}
