package com.cg.employee.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import com.cg.employee.dao.Employeedao;
import com.cg.employee.dao.IEmployeedao;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;



public class EmployeeService implements IEmployeeService{
	IEmployeedao dao=new Employeedao();

	
	public void setDao(Employeedao dao)
	{
		this.dao = dao;
	}

	@Override
	public int addEmployee(Employee obj) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.addEmployee(obj);
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}

	@Override
	public Employee getEmployeeId(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeId(empId);
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		String Pattern = "[A-Z]{1}[a-z]{2,}";
		if(java.util.regex.Pattern.matches(Pattern,name+""))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateSalary(int salary) {
		// TODO Auto-generated method stub
		//String Pattern = "[0-9]{3}"
		String Pattern = "[0-9]{4,6}";
		if(java.util.regex.Pattern.matches(Pattern,salary+""))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateId(int empId) {
		// TODO Auto-generated method stub
		String Pattern = "[0-9]{3}";
		if(java.util.regex.Pattern.matches(Pattern,empId+""))
			return true;
		else
		return false;
	}

	@Override
	public int RemoveById(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.RemoveById(empId);
	}

	@Override
	public int updateEmployee(int empId, int empsal) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.updateEmployee(empId, empsal);
	}

	
	
	
	
	
	
	
	
	
/*	public boolean validateDate(String date) {
		// TODO Auto-generated method stub
		DateTimeFormatter format=DateTimeFormatter.ofPattern("DD/MM/YYYY");
		LocalDate bDate=LocalDate.parse(date, format);
		if(bDate!=null)
			return true;
		else
		return false; */
	}
	

