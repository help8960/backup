package com.cg.employee.dao;

public class QueryMapper {
public static final String INSERTQUERY="insert into crmpune values(?,?,?,?)";
public static final String SELECTQUERY="select * from crmpune";
public static final String DELETEQUERY="delete crmpune where empid=?";  
public static final String SEARCHQUERY="select * from crmpune where empid=?";
public static final String UPDATEQUERY="update crmpune set empsal=empsal+? where empid=?";
}
