package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DBUtil;


public class Employeedao implements IEmployeedao{
Connection connection;
Logger logger;

public int generateEmployeeId() throws EmployeeException {
	// TODO Auto-generated method stub
	int EmployeeId = 0;
	String SQL = "select product_SEQ.nextval from dual";
	connection = DBUtil.getConnection();
	try {
		Statement statement = (Statement) connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL);
		resultSet.next();
		EmployeeId = resultSet.getInt(1);
	} catch (SQLException e) {
		e.printStackTrace();

	}
	return EmployeeId;
}

	@Override
	public int addEmployee(Employee obj) throws EmployeeException{
		// TODO Auto-generated method stub
		int empId=generateEmployeeId();
		connection = DBUtil.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTQUERY);
			preparedStatement.setLong(1, empId);
			preparedStatement.setString(2, obj.getEmpname());
			preparedStatement.setDouble(3,obj.getEmplsal());
			java.sql.Date date=Date.valueOf(obj.getBdate());
			preparedStatement.setDate(4, date);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return empId;
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException{
		// TODO Auto-generated method stub
		ArrayList<Employee> getall = new ArrayList<Employee>();
		connection = DBUtil.getConnection();
		Statement statement;
		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement
					.executeQuery(QueryMapper.SELECTQUERY);
			while (resultSet.next()) {
				Employee empobj = new Employee();
				empobj.setEmpid(resultSet.getInt(1));
				empobj.setEmpname(resultSet.getString(2));
				empobj.setEmplsal(resultSet.getInt(3));
				empobj.setBdate(resultSet.getDate(4).toLocalDate());
				//empobj.setBdate(resultSet.getLocalDate(4));
				getall.add(empobj);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return getall;

	}

	
	@Override
	public Employee getEmployeeId(int empId) throws EmployeeException {
		
		Employee ee=new Employee();
		try{
			 connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.SEARCHQUERY);
		
		preparedStatement.setInt(1,empId);

		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
		        ee.setEmpid(resultSet.getInt(1));
				ee.setEmpname(resultSet.getString(2));
				ee.setEmplsal(resultSet.getInt(3));
				ee.setBdate(resultSet.getDate(4).toLocalDate());
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ee;
		
	}

	@Override
	public int RemoveById(int empId) throws EmployeeException {
		
		
		Employee ee=new Employee();
		try{
			 connection = DBUtil.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.DELETEQUERY);
		
		preparedStatement.setInt(1,empId);
		preparedStatement.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//con.commit;
		return empId;
	}

	@Override
	public int updateEmployee(int empId,int empsal) throws EmployeeException {
		connection = DBUtil.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.UPDATEQUERY);
			
			preparedStatement.setInt(1,empsal);
			preparedStatement.setInt(2,empId);
			preparedStatement.executeUpdate();
			}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		return empId;



	}

}





















