package com.cg.employee.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.employee.dao.Employeedao;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;


public class EmployeeDaoTest {

	EmployeeService service;
	Employeedao dao;
	
	@Before
	public void init()
	{
		dao = new Employeedao();
		service = new EmployeeService();
		service.setDao(dao);
	}
	@Test
	public void testGetAllEmployee() throws EmployeeException
	{
		ArrayList<Employee>list = service.getAllEmployee();
		assertNotNull(list);
	}
	@Test
	public void testAddEmployee() throws EmployeeException
	{
		Employee emp = new Employee();
		emp.setEmpname("adarsh");
		emp.setEmplsal(4000);
		emp.setBdate(LocalDate.of(1988, Month.MAY, 27));
		
		int id = service.addEmployee(emp);
		assertNotSame(id,0);
	}
	@Test
	public void testDeleteEmployee() throws EmployeeException
	{
		int emp = service.RemoveById(101);
		assertNotNull(emp);
		
	}
	@Test
	public void updateEmployee() throws EmployeeException
	{
		int emp = service.updateEmployee(101, 6000);
		assertNotNull(emp);
	}
	@After
	public void destroy()
	{
		dao = null;
		service = null;
	}
	
}
